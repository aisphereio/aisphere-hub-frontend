# aisphere-kit v0.1.4-access-feature-flags

This release fixes the access-control feature-flag semantics introduced with `access.Guard`.

## Why

In v0.1.3, `Runtime.Authz` and `Runtime.Audit` could be non-nil whenever Casdoor was initialized for AuthN. That meant a business call to `rt.Access.Require(...)` could unexpectedly call Casdoor Enforce even when `features.authz=false`, causing validation/debug endpoints to fail before AuthZ was intentionally enabled.

## Changes

- `access.Options` now includes:
  - `AuthzEnabled bool`
  - `AuditEnabled bool`
- `access.Guard.Require/Can` now require an authenticated principal, but skip authorization decisions when `AuthzEnabled=false`.
- `access.Guard.Record` now no-ops when `AuditEnabled=false`.
- `starter.Runtime` now only assigns:
  - `rt.Authn` when `features.authn=true`
  - `rt.Authz` when `features.authz=true`
  - `rt.Audit` when `features.audit=true`
  - `rt.Permission` when `features.permission=true`
- Runtime initialization logs now distinguish:
  - `authz_enabled` vs `authz_configured`
  - `audit_enabled` vs `audit_configured`

## Validation intent

With only AuthN enabled:

```yaml
features:
  authn: true
  authz: false
  audit: false
```

business code can still call:

```go
rt.Access.Require(ctx, access.Check{Resource: "aihub:admin", Action: "admin.access"})
```

and it will require a valid principal but will not call Casdoor Enforce.

With AuthZ enabled:

```yaml
features:
  authz: true
```

`rt.Access.Require(...)` will call the configured `authz.Authorizer` and fail closed on deny/configuration errors.

## v1.5.0 - Migration Runner

This release adds a production-oriented SQL migration runner for Postgres. It intentionally replaces service-local `AutoMigrate` usage with versioned SQL files managed by kit.

Example:

```yaml
migration:
  enabled: true
  auto_apply: false
  driver: postgres
  path: ./migrations/postgres
  table: schema_migrations
  lock: true
  allow_dirty: false
  timeout: 30s
```

When `auto_apply=true`, runtime applies pending migrations after DB initialization and before the application server starts.


## v1.6.4 - Casdoor Config Simplification

- Prefer `casdoor.permission_id` for global RBAC and `casdoor.policy_enforcer` for dynamic sharing.
- Keep low-level `model_id`, `resource_id`, `enforcer_id`, and `owner` empty in normal services.
- `policy_enforcer` now accepts short names and is normalized to `owner/name` for Casdoor Enforce.
- `policy_adapter_id` now accepts short names and defaults to `<organization>/aisphere_policy_rule` when omitted.
- This removes the need to duplicate `enforcer_id` and `policy_enforcer` in service configs.
