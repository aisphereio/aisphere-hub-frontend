package casdoor

import (
	"testing"

	"github.com/actionlab-ai/aisphere-kit/principal"
)

func TestCasdoorSubjectPrefersOwnerNameOverJWTSubjectClaim(t *testing.T) {
	p := &principal.Principal{
		SubjectType: principal.SubjectUser,
		SubjectID:   "admin",
		OrgID:       "aisphere",
		Claims: map[string]any{
			"subject": "d03b68bc-e865-4d7d-9543-29819533965d",
		},
	}

	if got := casdoorSubject(p); got != "aisphere/admin" {
		t.Fatalf("casdoorSubject() = %q, want %q", got, "aisphere/admin")
	}
}

func TestCasdoorSubjectFallsBackToJWTSubjectClaim(t *testing.T) {
	p := &principal.Principal{
		SubjectType: principal.SubjectUser,
		Claims: map[string]any{
			"subject": "aisphere/admin",
		},
	}

	if got := casdoorSubject(p); got != "aisphere/admin" {
		t.Fatalf("casdoorSubject() = %q, want %q", got, "aisphere/admin")
	}
}

func TestCasdoorSubjectFallsBackToPrincipalSubject(t *testing.T) {
	p := &principal.Principal{
		SubjectType: principal.SubjectUser,
		SubjectID:   "admin",
	}

	if got := casdoorSubject(p); got != "user:admin" {
		t.Fatalf("casdoorSubject() = %q, want %q", got, "user:admin")
	}
}
