package casdoor

import (
	"context"
	"fmt"
	"log/slog"
	"strings"
	"time"

	"github.com/actionlab-ai/aisphere-kit/permission"
	"github.com/actionlab-ai/aisphere-kit/resource"
	"github.com/actionlab-ai/aisphere-kit/retry"
	casdoorsdk "github.com/casdoor/casdoor-go-sdk/casdoorsdk"
)

func (a *Adapter) Grant(ctx context.Context, grant permission.Grant) error {
	g, err := permission.NormalizeGrant(grant)
	if err != nil {
		return err
	}
	if g.Action == "" {
		return a.GrantRole(ctx, g)
	}
	return a.addPolicy(ctx, g.Subject, g.Resource.String(), g.Action)
}

func (a *Adapter) GrantRole(ctx context.Context, grant permission.Grant) error {
	g, err := permission.NormalizeGrant(grant)
	if err != nil {
		return err
	}
	actions, err := permission.RoleActionsForResource(g.Resource, g.Role, g.Actions)
	if err != nil {
		return err
	}
	for _, act := range actions {
		if err := a.addPolicy(ctx, g.Subject, g.Resource.String(), act); err != nil {
			return err
		}
	}
	return nil
}

func (a *Adapter) Share(ctx context.Context, req permission.ShareRequest) error {
	g, err := permission.NormalizeShare(req)
	if err != nil {
		return err
	}
	return a.GrantRole(ctx, g)
}

func (a *Adapter) Revoke(ctx context.Context, grant permission.Grant) error {
	g, err := permission.NormalizeGrant(grant)
	if err != nil {
		return err
	}
	actions := []string{g.Action}
	if g.Action == "" {
		actions, err = permission.RoleActionsForResource(g.Resource, g.Role, g.Actions)
		if err != nil {
			return err
		}
	}
	for _, act := range actions {
		if err := a.removePolicy(ctx, g.Subject, g.Resource.String(), act); err != nil {
			return err
		}
	}
	return nil
}

// Check evaluates one dynamic policy-management request against the configured
// policy enforcer. It intentionally does not use the global permission_id
// selector. Use Authorize for the normal request path that combines global RBAC
// and dynamic-share fallback.
func (a *Adapter) Check(ctx context.Context, req permission.CheckRequest) (bool, error) {
	subject := strings.TrimSpace(req.Subject)
	if subject == "" && req.Principal != nil {
		subject = casdoorSubject(req.Principal)
	}
	if subject == "" {
		return false, permission.ErrEmptySubject
	}
	if req.Resource.String() == "" {
		return false, permission.ErrEmptyResource
	}
	if req.Action == "" {
		return false, permission.ErrEmptyAction
	}
	target, ok := a.policyEnforceTarget()
	if !ok {
		return false, fmt.Errorf("casdoor policy_enforcer or enforcer_id is required for dynamic policy check")
	}

	casbinReq := casdoorsdk.CasbinRequest{subject, req.Resource.String(), req.Action}
	if req.Domain != "" {
		casbinReq = casdoorsdk.CasbinRequest{subject, req.Domain, req.Resource.String(), req.Action}
	}
	if len(req.Extra) > 0 {
		casbinReq = append(casbinReq, req.Extra...)
	}
	return a.enforce(ctx, "dynamic_permission_check", target, casbinReq, a.logger.With("subject", subject, "resource", req.Resource.String(), "action", req.Action))
}

// ValidatePolicyBackend verifies that the configured Casdoor policy-management
// target is usable before a service starts accepting share operations. This is a
// fail-fast guard for common Casdoor setup mistakes such as an Enforcer without
// a bound Model.
func (a *Adapter) ValidatePolicyBackend(ctx context.Context) error {
	enforcer, adapterID, err := a.policyTarget()
	if err != nil {
		return err
	}
	enforcerName, readAdapterID, err := a.policyReadTarget()
	if err != nil {
		return err
	}
	started := time.Now()
	l := a.logger.With("enforcer", enforcer.Name, "adapter_id", adapterID)
	l.Debug("casdoor policy backend validation started")
	var rules []*casdoorsdk.CasbinRule
	err = retry.Do(ctx, a.retry, func() error {
		return callWithContext(ctx, func() error {
			var e error
			rules, e = a.client.GetPolicies(enforcerName, readAdapterID)
			return e
		})
	})
	if a.metrics != nil {
		a.metrics.ObserveDependency("casdoor", "validate_policy_backend", started, err)
	}
	if err != nil {
		l.Warn("casdoor policy backend validation failed", "error", err, "elapsed", time.Since(started).String())
		return fmt.Errorf("validate casdoor dynamic policy backend enforcer=%q adapter_id=%q: %w; check Casdoor Enforcer is bound to the same three-field Model and that the Model Adapter table name is configured", enforcer.Name, adapterID, err)
	}
	l.Info("casdoor policy backend validation completed", "policy_count", len(rules), "elapsed", time.Since(started).String())
	return nil
}

func (a *Adapter) List(ctx context.Context, filter permission.ListFilter) ([]permission.Grant, error) {
	enforcer, adapterID, err := a.policyTarget()
	if err != nil {
		return nil, err
	}
	enforcerName, readAdapterID, err := a.policyReadTarget()
	if err != nil {
		return nil, err
	}
	started := time.Now()
	l := a.logger.With("enforcer", enforcer.Name, "adapter_id", adapterID, "resource", filter.Resource.String())
	l.Debug("casdoor list policies started")
	var rules []*casdoorsdk.CasbinRule
	err = retry.Do(ctx, a.retry, func() error {
		return callWithContext(ctx, func() error {
			var e error
			rules, e = a.client.GetPolicies(enforcerName, readAdapterID)
			return e
		})
	})
	if a.metrics != nil {
		a.metrics.ObserveDependency("casdoor", "get_policies", started, err)
	}
	if err != nil {
		l.Warn("casdoor list policies failed", "error", err, "elapsed", time.Since(started).String())
		return nil, err
	}
	grants := make([]permission.Grant, 0, len(rules))
	for _, r := range rules {
		if r == nil || r.Ptype != "p" {
			continue
		}
		g := permission.Grant{Subject: r.V0, Resource: resource.Name(r.V1), Action: r.V2}
		if filter.Subject != "" && filter.Subject != g.Subject {
			continue
		}
		if filter.Resource.String() != "" && filter.Resource != g.Resource {
			continue
		}
		if filter.Action != "" && filter.Action != g.Action {
			continue
		}
		grants = append(grants, g)
	}
	l.Debug("casdoor list policies completed", "matched", len(grants), "elapsed", time.Since(started).String())
	return grants, nil
}

func (a *Adapter) DeleteResourcePolicies(ctx context.Context, res resource.Name) error {
	return a.DeleteResourcePoliciesEx(ctx, permission.DeleteResourceRequest{Resource: res})
}

func (a *Adapter) DeleteResourcePoliciesEx(ctx context.Context, req permission.DeleteResourceRequest) error {
	if req.Resource.String() == "" {
		return permission.ErrEmptyResource
	}
	grants, err := a.List(ctx, permission.ListFilter{Resource: req.Resource})
	if err != nil {
		return err
	}
	l := a.logger.With("resource", req.Resource.String(), "policy_count", len(grants), "reason", req.Reason, "actor", req.Actor)
	l.Info("casdoor delete resource policies started")
	for _, g := range grants {
		if err := a.removePolicy(ctx, g.Subject, g.Resource.String(), g.Action); err != nil {
			l.Warn("casdoor delete resource policy failed", "subject", g.Subject, "action", g.Action, "error", err)
			return err
		}
	}
	l.Info("casdoor delete resource policies completed")
	return nil
}

func (a *Adapter) addPolicy(ctx context.Context, subject, object, action string) error {
	enforcer, _, err := a.policyTarget()
	if err != nil {
		return err
	}
	rule := &casdoorsdk.CasbinRule{Ptype: "p", V0: subject, V1: object, V2: action}
	started := time.Now()
	l := a.logger.With("subject", subject, "resource", object, "action", action, "enforcer", enforcer.Name)
	l.Debug("casdoor add policy started")
	err = retry.Do(ctx, a.retry, func() error {
		return callWithContext(ctx, func() error {
			ok, err := a.client.AddPolicy(enforcer, rule)
			if err != nil {
				return err
			}
			if !ok {
				l.Debug("casdoor add policy returned false; treating as no-op/idempotent")
			}
			return nil
		})
	})
	if a.metrics != nil {
		a.metrics.ObserveDependency("casdoor", "add_policy", started, err)
	}
	if err != nil {
		l.Warn("casdoor add policy failed", "error", err, "elapsed", time.Since(started).String())
		return err
	}
	l.Info("casdoor add policy completed", "elapsed", time.Since(started).String())
	return nil
}

func (a *Adapter) removePolicy(ctx context.Context, subject, object, action string) error {
	enforcer, _, err := a.policyTarget()
	if err != nil {
		return err
	}
	rule := &casdoorsdk.CasbinRule{Ptype: "p", V0: subject, V1: object, V2: action}
	started := time.Now()
	l := a.logger.With("subject", subject, "resource", object, "action", action, "enforcer", enforcer.Name)
	l.Debug("casdoor remove policy started")
	err = retry.Do(ctx, a.retry, func() error {
		return callWithContext(ctx, func() error {
			ok, err := a.client.RemovePolicy(enforcer, rule)
			if err != nil {
				return err
			}
			if !ok {
				l.Debug("casdoor remove policy returned false; treating as no-op/idempotent")
			}
			return nil
		})
	})
	if a.metrics != nil {
		a.metrics.ObserveDependency("casdoor", "remove_policy", started, err)
	}
	if err != nil {
		l.Warn("casdoor remove policy failed", "error", err, "elapsed", time.Since(started).String())
		return err
	}
	l.Info("casdoor remove policy completed", "elapsed", time.Since(started).String())
	return nil
}

func (a *Adapter) policyTarget() (*casdoorsdk.Enforcer, string, error) {
	owner, name, err := a.policyEnforcerOwnerName()
	if err != nil {
		return nil, "", err
	}
	adapterID, err := a.policyAdapterID(owner)
	if err != nil {
		return nil, "", err
	}
	return &casdoorsdk.Enforcer{Owner: owner, Name: name}, adapterID, nil
}

func (a *Adapter) policyReadTarget() (string, string, error) {
	owner, name, err := a.policyEnforcerOwnerName()
	if err != nil {
		return "", "", err
	}
	if owner != strings.TrimSpace(a.cfg.Organization) {
		return "", "", fmt.Errorf("casdoor GetPolicies SDK requires policy_enforcer owner %q to match organization %q", owner, a.cfg.Organization)
	}
	// Casdoor's get-policies endpoint returns policy rules only when adapterId is
	// empty. Supplying adapterId initializes the adapter and returns an empty OK.
	return name, "", nil
}

type enforceTarget struct {
	permissionID string
	modelID      string
	resourceID   string
	enforcerID   string
	owner        string
	name         string
}

func (t enforceTarget) isZero() bool {
	return t.permissionID == "" && t.modelID == "" && t.resourceID == "" && t.enforcerID == "" && t.owner == ""
}

func (t enforceTarget) same(u enforceTarget) bool {
	return t.permissionID == u.permissionID && t.modelID == u.modelID && t.resourceID == u.resourceID && t.enforcerID == u.enforcerID && t.owner == u.owner
}

func (a *Adapter) primaryEnforceTarget() enforceTarget {
	permissionID, modelID, resourceID, enforcerID, owner := a.enforceSelectors()
	return enforceTarget{permissionID: permissionID, modelID: modelID, resourceID: resourceID, enforcerID: enforcerID, owner: owner, name: "global"}
}

func (a *Adapter) policyEnforceTarget() (enforceTarget, bool) {
	owner, name, err := a.policyEnforcerOwnerName()
	if err != nil {
		return enforceTarget{}, false
	}
	return enforceTarget{enforcerID: owner + "/" + name, name: "dynamic_policy"}, true
}

func (a *Adapter) policyEnforcerOwnerName() (owner string, name string, err error) {
	raw := strings.TrimSpace(a.cfg.PolicyEnforcer)
	if raw == "" {
		// Backward compatibility: older configs used enforcer_id for the dynamic
		// policy enforcer. New service configs should keep enforcer_id empty and use
		// policy_enforcer only, so global RBAC and dynamic sharing stay separate.
		raw = strings.TrimSpace(a.cfg.EnforcerID)
	}
	if raw == "" {
		return "", "", fmt.Errorf("casdoor policy_enforcer or enforcer_id is required for policy management")
	}
	parts := strings.Split(raw, "/")
	switch len(parts) {
	case 1:
		owner = strings.TrimSpace(a.cfg.Organization)
		name = strings.TrimSpace(parts[0])
	case 2:
		owner = strings.TrimSpace(parts[0])
		name = strings.TrimSpace(parts[1])
	default:
		return "", "", fmt.Errorf("invalid casdoor policy_enforcer %q: expected name or owner/name", raw)
	}
	if owner == "" || name == "" {
		return "", "", fmt.Errorf("invalid casdoor policy_enforcer %q: owner and name are required", raw)
	}
	return owner, name, nil
}

func (a *Adapter) policyAdapterID(owner string) (string, error) {
	raw := strings.TrimSpace(a.cfg.PolicyAdapterID)
	if raw == "" {
		// Standard platform convention. The Casdoor Adapter object still belongs to
		// Casdoor; services do not create or migrate this table.
		raw = "aisphere_policy_rule"
	}
	parts := strings.Split(raw, "/")
	switch len(parts) {
	case 1:
		name := strings.TrimSpace(parts[0])
		if owner == "" || name == "" {
			return "", fmt.Errorf("invalid casdoor policy_adapter_id %q: owner and name are required", raw)
		}
		return owner + "/" + name, nil
	case 2:
		o := strings.TrimSpace(parts[0])
		n := strings.TrimSpace(parts[1])
		if o == "" || n == "" {
			return "", fmt.Errorf("invalid casdoor policy_adapter_id %q: owner and name are required", raw)
		}
		return o + "/" + n, nil
	default:
		return "", fmt.Errorf("invalid casdoor policy_adapter_id %q: expected name or owner/name", raw)
	}
}

func (a *Adapter) enforce(ctx context.Context, operation string, target enforceTarget, req casdoorsdk.CasbinRequest, l *slog.Logger) (bool, error) {
	if target.isZero() {
		return false, fmt.Errorf("casdoor enforce target is empty")
	}
	started := time.Now()
	if l == nil {
		l = a.logger
	}
	l = l.With("selector", target.name, "permission_id", target.permissionID, "model_id", target.modelID, "resource_id", target.resourceID, "enforcer_id", target.enforcerID, "owner", target.owner)
	l.Debug("casdoor enforce started")
	var allowed bool
	err := retry.Do(ctx, a.retry, func() error {
		return callWithContext(ctx, func() error {
			v, err := a.client.Enforce(target.permissionID, target.modelID, target.resourceID, target.enforcerID, target.owner, req)
			allowed = v
			return err
		})
	})
	if a.metrics != nil {
		a.metrics.ObserveDependency("casdoor", operation, started, err)
	}
	if err != nil {
		l.Warn("casdoor enforce failed", "error", err, "elapsed", time.Since(started).String())
		return false, err
	}
	l.Debug("casdoor enforce completed", "allowed", allowed, "elapsed", time.Since(started).String())
	return allowed, nil
}

func logPolicyDebug(l *slog.Logger, msg string, args ...any) {
	if l != nil {
		l.Debug(msg, args...)
	}
}
