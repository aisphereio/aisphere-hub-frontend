package casdoor

import "testing"

func TestPolicyReadTargetUsesSDKListConvention(t *testing.T) {
	a := &Adapter{cfg: Config{Organization: "aisphere", PolicyEnforcer: "enforcer_aisphere", PolicyAdapterID: "aisphere_policy_rule"}}

	enforcerName, adapterID, err := a.policyReadTarget()
	if err != nil {
		t.Fatal(err)
	}

	if enforcerName != "enforcer_aisphere" {
		t.Fatalf("enforcerName=%q, want SDK short enforcer name", enforcerName)
	}
	if adapterID != "" {
		t.Fatalf("adapterID=%q, want empty adapterID so Casdoor returns policies", adapterID)
	}
}
