package casdoor

import (
	"strings"

	"github.com/actionlab-ai/aisphere-kit/principal"
)

func casdoorSubject(p *principal.Principal) string {
	if p == nil {
		return ""
	}
	if p.OrgID != "" && p.SubjectID != "" {
		return strings.TrimSpace(p.OrgID) + "/" + strings.TrimSpace(p.SubjectID)
	}
	if subject, ok := p.Claims["subject"].(string); ok {
		if subject = strings.TrimSpace(subject); subject != "" {
			return subject
		}
	}
	return p.Subject()
}
