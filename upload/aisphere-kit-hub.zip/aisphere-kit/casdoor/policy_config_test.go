package casdoor

import "testing"

func TestPolicyTargetNormalizesShortNames(t *testing.T) {
	a := &Adapter{cfg: Config{Organization: "aisphere", PolicyEnforcer: "enforcer_aisphere", PolicyAdapterID: "aisphere_policy_rule"}}
	enforcer, adapterID, err := a.policyTarget()
	if err != nil {
		t.Fatal(err)
	}
	if enforcer.Owner != "aisphere" || enforcer.Name != "enforcer_aisphere" {
		t.Fatalf("unexpected enforcer: owner=%q name=%q", enforcer.Owner, enforcer.Name)
	}
	if adapterID != "aisphere/aisphere_policy_rule" {
		t.Fatalf("adapterID=%q, want aisphere/aisphere_policy_rule", adapterID)
	}

	target, ok := a.policyEnforceTarget()
	if !ok {
		t.Fatal("expected dynamic policy target")
	}
	if target.enforcerID != "aisphere/enforcer_aisphere" {
		t.Fatalf("dynamic enforcerID=%q, want aisphere/enforcer_aisphere", target.enforcerID)
	}
}

func TestPolicyTargetDefaultsAdapterID(t *testing.T) {
	a := &Adapter{cfg: Config{Organization: "aisphere", PolicyEnforcer: "enforcer_aisphere"}}
	_, adapterID, err := a.policyTarget()
	if err != nil {
		t.Fatal(err)
	}
	if adapterID != "aisphere/aisphere_policy_rule" {
		t.Fatalf("adapterID=%q, want default aisphere/aisphere_policy_rule", adapterID)
	}
}

func TestPolicyTargetAcceptsFullIDs(t *testing.T) {
	a := &Adapter{cfg: Config{Organization: "aisphere", PolicyEnforcer: "other/enforcer_x", PolicyAdapterID: "other/adapter_x"}}
	enforcer, adapterID, err := a.policyTarget()
	if err != nil {
		t.Fatal(err)
	}
	if enforcer.Owner != "other" || enforcer.Name != "enforcer_x" {
		t.Fatalf("unexpected enforcer: owner=%q name=%q", enforcer.Owner, enforcer.Name)
	}
	if adapterID != "other/adapter_x" {
		t.Fatalf("adapterID=%q, want other/adapter_x", adapterID)
	}
}
