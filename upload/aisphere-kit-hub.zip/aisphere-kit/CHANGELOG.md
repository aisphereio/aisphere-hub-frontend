# Changelog

## v0.1.4-access-feature-flags

- Added explicit `AuthzEnabled` and `AuditEnabled` flags to `access.Guard`.
- `Require/Can` now skip Casdoor Enforce when `features.authz=false`, while still requiring an authenticated principal.
- `Record` now no-ops when `features.audit=false`.
- `starter.Runtime` now wires `rt.Authz` and `rt.Audit` only when their feature flags are enabled.
- Improved runtime logs for access guard feature status.

## v0.1.3-access-guard

- Added reusable `access.Guard` package.
- Added `starter.Runtime.Access` initialized from runtime Authz/Audit adapters.
- Preserved v0.1.2 Casdoor JWT certificate startup validation.

## v0.1.2-casdoor-cert-fix

- Added `casdoor.certificate_file`.
- Added startup validation for Casdoor JWT public certificate/public key when Authn is enabled.
- Added `casdoor.NewChecked()`.

## v1.5.0 - Migration Runner

- Added `migration` package for PostgreSQL SQL migrations.
- Added `config.Config.Migration` with `enabled`, `auto_apply`, `path`, `table`, `lock`, `allow_dirty`, and `timeout`.
- Runtime now initializes a migration runner after DB initialization and can auto-apply migrations when `migration.auto_apply=true`.
- Added checksum, dirty-state detection, duplicate-version detection, and PostgreSQL advisory lock support.


## v1.6.4 - Casdoor Config Simplification

- Prefer `casdoor.permission_id` for global RBAC and `casdoor.policy_enforcer` for dynamic sharing.
- Keep low-level `model_id`, `resource_id`, `enforcer_id`, and `owner` empty in normal services.
- `policy_enforcer` now accepts short names and is normalized to `owner/name` for Casdoor Enforce.
- `policy_adapter_id` now accepts short names and defaults to `<organization>/aisphere_policy_rule` when omitted.
- This removes the need to duplicate `enforcer_id` and `policy_enforcer` in service configs.
