# Verify aisphere-kit v0.1.4-access-feature-flags

Run locally with module download access:

```bash
go test ./...
```

Manual behavior expected in a Hub service using this kit:

1. With `features.authn=true`, `features.authz=false`, `features.audit=false`:
   - `/v3/auth/me` requires a valid Bearer token.
   - business calls to `rt.Access.Require(...)` allow authenticated users and do not call Casdoor Enforce.
   - `rt.Access.Record(...)` is a no-op.
2. With `features.authz=true` and a valid Casdoor `permission_id`/selector:
   - `rt.Access.Require(...)` calls Casdoor Enforce.
   - missing policy returns denied / 403 in the caller.
   - matching policy returns allowed.
3. With `features.audit=true`:
   - `rt.Access.Record(...)` calls Casdoor `AddRecord`.

## Verify migration runner

```bash
go test ./migration
```

In an environment with module access, run:

```bash
go test ./...
```


## v1.6.4 - Casdoor Config Simplification

- Prefer `casdoor.permission_id` for global RBAC and `casdoor.policy_enforcer` for dynamic sharing.
- Keep low-level `model_id`, `resource_id`, `enforcer_id`, and `owner` empty in normal services.
- `policy_enforcer` now accepts short names and is normalized to `owner/name` for Casdoor Enforce.
- `policy_adapter_id` now accepts short names and defaults to `<organization>/aisphere_policy_rule` when omitted.
- This removes the need to duplicate `enforcer_id` and `policy_enforcer` in service configs.
