package migration

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"gorm.io/gorm"
)

type Runner struct {
	db     *gorm.DB
	cfg    Config
	logger *slog.Logger
}

type Option func(*Runner)

func WithLogger(l *slog.Logger) Option { return func(r *Runner) { r.logger = l } }

type Migration struct {
	Version  int64
	Name     string
	Path     string
	Checksum string
}

type AppliedMigration struct {
	Version         int64
	Name            string
	Checksum        string
	AppliedAt       time.Time
	ExecutionTimeMS int64
	Dirty           bool
	Error           string
}

type Status struct {
	Applied []AppliedMigration
	Pending []Migration
	Dirty   []AppliedMigration
}

func NewRunner(db *gorm.DB, cfg Config, opts ...Option) (*Runner, error) {
	if db == nil {
		return nil, fmt.Errorf("migration db is nil")
	}
	cfg = cfg.Normalized()
	if err := cfg.Validate(); err != nil {
		return nil, err
	}
	r := &Runner{db: db, cfg: cfg, logger: slog.Default()}
	for _, opt := range opts {
		if opt != nil {
			opt(r)
		}
	}
	return r, nil
}

func (r *Runner) Up(ctx context.Context) error {
	if r == nil {
		return fmt.Errorf("migration runner is nil")
	}
	if !r.cfg.Enabled {
		return nil
	}
	ctx, cancel := context.WithTimeout(ctx, r.cfg.TimeoutDuration())
	defer cancel()

	if err := r.ensureTable(ctx); err != nil {
		return err
	}
	if r.cfg.Lock {
		if err := r.lock(ctx); err != nil {
			return err
		}
		defer func() { _ = r.unlock(context.Background()) }()
	}

	applied, err := r.applied(ctx)
	if err != nil {
		return err
	}
	for _, m := range applied {
		if m.Dirty && !r.cfg.AllowDirty {
			return fmt.Errorf("migration dirty at version %d (%s): %s", m.Version, m.Name, m.Error)
		}
	}

	files, err := r.loadMigrations()
	if err != nil {
		return err
	}
	for _, f := range files {
		if old, ok := applied[f.Version]; ok {
			if old.Checksum != f.Checksum {
				return fmt.Errorf("migration checksum mismatch for version %d (%s): db=%s file=%s", f.Version, f.Name, old.Checksum, f.Checksum)
			}
			continue
		}
		if err := r.applyOne(ctx, f); err != nil {
			return err
		}
	}
	return nil
}

func (r *Runner) Status(ctx context.Context) (*Status, error) {
	if r == nil {
		return nil, fmt.Errorf("migration runner is nil")
	}
	if err := r.ensureTable(ctx); err != nil {
		return nil, err
	}
	appliedMap, err := r.applied(ctx)
	if err != nil {
		return nil, err
	}
	files, err := r.loadMigrations()
	if err != nil {
		return nil, err
	}
	st := &Status{}
	for _, a := range appliedMap {
		st.Applied = append(st.Applied, a)
		if a.Dirty {
			st.Dirty = append(st.Dirty, a)
		}
	}
	sort.Slice(st.Applied, func(i, j int) bool { return st.Applied[i].Version < st.Applied[j].Version })
	sort.Slice(st.Dirty, func(i, j int) bool { return st.Dirty[i].Version < st.Dirty[j].Version })
	for _, f := range files {
		if _, ok := appliedMap[f.Version]; !ok {
			st.Pending = append(st.Pending, f)
		}
	}
	return st, nil
}

func (r *Runner) Version(ctx context.Context) (int64, bool, error) {
	if r == nil {
		return 0, false, fmt.Errorf("migration runner is nil")
	}
	if err := r.ensureTable(ctx); err != nil {
		return 0, false, err
	}
	applied, err := r.applied(ctx)
	if err != nil {
		return 0, false, err
	}
	var max int64
	dirty := false
	for _, a := range applied {
		if a.Version > max {
			max = a.Version
		}
		dirty = dirty || a.Dirty
	}
	return max, dirty, nil
}

func (r *Runner) ensureTable(ctx context.Context) error {
	q := fmt.Sprintf(`CREATE TABLE IF NOT EXISTS %s (
        version BIGINT PRIMARY KEY,
        name TEXT NOT NULL,
        checksum TEXT NOT NULL,
        applied_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        execution_time_ms BIGINT NOT NULL DEFAULT 0,
        dirty BOOLEAN NOT NULL DEFAULT false,
        error TEXT NOT NULL DEFAULT ''
    )`, r.cfg.Table)
	if err := r.db.WithContext(ctx).Exec(q).Error; err != nil {
		return fmt.Errorf("ensure migration table: %w", err)
	}
	return nil
}

func (r *Runner) applied(ctx context.Context) (map[int64]AppliedMigration, error) {
	rows := []AppliedMigration{}
	q := fmt.Sprintf("SELECT version, name, checksum, applied_at, execution_time_ms, dirty, error FROM %s ORDER BY version", r.cfg.Table)
	if err := r.db.WithContext(ctx).Raw(q).Scan(&rows).Error; err != nil {
		return nil, fmt.Errorf("load applied migrations: %w", err)
	}
	out := make(map[int64]AppliedMigration, len(rows))
	for _, row := range rows {
		out[row.Version] = row
	}
	return out, nil
}

func (r *Runner) loadMigrations() ([]Migration, error) {
	matches, err := filepath.Glob(filepath.Join(r.cfg.Path, "*.sql"))
	if err != nil {
		return nil, fmt.Errorf("glob migrations: %w", err)
	}
	out := make([]Migration, 0, len(matches))
	for _, path := range matches {
		m, err := parseMigrationFile(path)
		if err != nil {
			return nil, err
		}
		b, err := os.ReadFile(path)
		if err != nil {
			return nil, fmt.Errorf("read migration %s: %w", path, err)
		}
		sum := sha256.Sum256(b)
		m.Checksum = hex.EncodeToString(sum[:])
		out = append(out, m)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Version < out[j].Version })
	for i := 1; i < len(out); i++ {
		if out[i].Version == out[i-1].Version {
			return nil, fmt.Errorf("duplicate migration version %d: %s and %s", out[i].Version, out[i-1].Name, out[i].Name)
		}
	}
	return out, nil
}

func (r *Runner) applyOne(ctx context.Context, m Migration) error {
	b, err := os.ReadFile(m.Path)
	if err != nil {
		return fmt.Errorf("read migration %s: %w", m.Path, err)
	}
	sqlText := strings.TrimSpace(string(b))
	if sqlText == "" {
		return fmt.Errorf("migration %s is empty", m.Name)
	}

	started := time.Now()
	r.logger.Info("migration apply started", "version", m.Version, "name", m.Name)
	markDirty := fmt.Sprintf(`INSERT INTO %s (version, name, checksum, applied_at, execution_time_ms, dirty, error)
        VALUES (?, ?, ?, now(), 0, true, '')
        ON CONFLICT (version) DO UPDATE SET name = EXCLUDED.name, checksum = EXCLUDED.checksum, applied_at = now(), dirty = true, error = ''`, r.cfg.Table)
	if err := r.db.WithContext(ctx).Exec(markDirty, m.Version, m.Name, m.Checksum).Error; err != nil {
		return fmt.Errorf("mark migration %d dirty: %w", m.Version, err)
	}

	tx := r.db.WithContext(ctx).Begin()
	if tx.Error != nil {
		return fmt.Errorf("begin migration %d: %w", m.Version, tx.Error)
	}
	if err := tx.Exec(sqlText).Error; err != nil {
		_ = tx.Rollback()
		_ = r.markFailed(ctx, m, err)
		return fmt.Errorf("apply migration %d %s: %w", m.Version, m.Name, err)
	}
	elapsed := time.Since(started).Milliseconds()
	markClean := fmt.Sprintf(`UPDATE %s SET dirty = false, error = '', execution_time_ms = ?, applied_at = now() WHERE version = ?`, r.cfg.Table)
	if err := tx.Exec(markClean, elapsed, m.Version).Error; err != nil {
		_ = tx.Rollback()
		_ = r.markFailed(ctx, m, err)
		return fmt.Errorf("mark migration %d clean: %w", m.Version, err)
	}
	if err := tx.Commit().Error; err != nil {
		_ = r.markFailed(ctx, m, err)
		return fmt.Errorf("commit migration %d: %w", m.Version, err)
	}
	r.logger.Info("migration apply completed", "version", m.Version, "name", m.Name, "elapsed_ms", elapsed)
	return nil
}

func (r *Runner) markFailed(ctx context.Context, m Migration, cause error) error {
	q := fmt.Sprintf(`UPDATE %s SET dirty = true, error = ? WHERE version = ?`, r.cfg.Table)
	msg := cause.Error()
	if len(msg) > 2000 {
		msg = msg[:2000]
	}
	return r.db.WithContext(ctx).Exec(q, msg, m.Version).Error
}

func (r *Runner) lock(ctx context.Context) error {
	return r.db.WithContext(ctx).Exec("SELECT pg_advisory_lock(hashtext(?))", r.lockKey()).Error
}

func (r *Runner) unlock(ctx context.Context) error {
	return r.db.WithContext(ctx).Exec("SELECT pg_advisory_unlock(hashtext(?))", r.lockKey()).Error
}

func (r *Runner) lockKey() string { return "aisphere-kit:migration:" + r.cfg.Table }

var migrationFileRe = regexp.MustCompile(`^(\d+)[._-].*\.sql$`)
var tableNameRe = regexp.MustCompile(`^[A-Za-z_][A-Za-z0-9_]*$`)

func parseMigrationFile(path string) (Migration, error) {
	base := filepath.Base(path)
	match := migrationFileRe.FindStringSubmatch(base)
	if len(match) != 2 {
		return Migration{}, fmt.Errorf("invalid migration filename %q; expected NNN_name.sql", base)
	}
	version, err := strconv.ParseInt(match[1], 10, 64)
	if err != nil {
		return Migration{}, fmt.Errorf("parse migration version %q: %w", base, err)
	}
	if version <= 0 {
		return Migration{}, fmt.Errorf("migration version must be positive: %q", base)
	}
	return Migration{Version: version, Name: base, Path: path}, nil
}

func validateTableName(table string) error {
	if !tableNameRe.MatchString(table) {
		return fmt.Errorf("migration.table %q is invalid; use a simple SQL identifier", table)
	}
	return nil
}

var ErrNoMigrations = errors.New("no migrations")
