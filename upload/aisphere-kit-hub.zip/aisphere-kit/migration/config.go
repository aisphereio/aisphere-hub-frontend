package migration

import (
	"fmt"
	"strings"
	"time"
)

type Config struct {
	Enabled    bool   `json:"enabled" yaml:"enabled"`
	AutoApply  bool   `json:"auto_apply" yaml:"auto_apply"`
	Driver     string `json:"driver" yaml:"driver"`
	Path       string `json:"path" yaml:"path"`
	Table      string `json:"table" yaml:"table"`
	Lock       bool   `json:"lock" yaml:"lock"`
	AllowDirty bool   `json:"allow_dirty" yaml:"allow_dirty"`
	Timeout    string `json:"timeout" yaml:"timeout"`
}

func DefaultConfig() Config {
	return Config{
		Enabled:    false,
		AutoApply:  false,
		Driver:     "postgres",
		Path:       "./migrations/postgres",
		Table:      "schema_migrations",
		Lock:       true,
		AllowDirty: false,
		Timeout:    "30s",
	}
}

func (c Config) Normalized() Config {
	d := DefaultConfig()
	if c.Driver != "" {
		d.Driver = strings.ToLower(strings.TrimSpace(c.Driver))
	}
	if c.Path != "" {
		d.Path = strings.TrimSpace(c.Path)
	}
	if c.Table != "" {
		d.Table = strings.TrimSpace(c.Table)
	}
	if c.Timeout != "" {
		d.Timeout = strings.TrimSpace(c.Timeout)
	}
	d.Enabled = c.Enabled
	d.AutoApply = c.AutoApply
	d.Lock = c.Lock
	d.AllowDirty = c.AllowDirty
	return d
}

func (c Config) Validate() error {
	if !c.Enabled {
		return nil
	}
	n := c.Normalized()
	if n.Driver != "postgres" {
		return fmt.Errorf("migration.driver only supports postgres")
	}
	if n.Path == "" {
		return fmt.Errorf("migration.path is required when migration.enabled=true")
	}
	if n.Table == "" {
		return fmt.Errorf("migration.table is required when migration.enabled=true")
	}
	if _, err := time.ParseDuration(n.Timeout); err != nil {
		return fmt.Errorf("migration.timeout: %w", err)
	}
	if err := validateTableName(n.Table); err != nil {
		return err
	}
	return nil
}

func (c Config) TimeoutDuration() time.Duration {
	n := c.Normalized()
	d, err := time.ParseDuration(n.Timeout)
	if err != nil {
		return 30 * time.Second
	}
	return d
}
