package migration

import "testing"

func TestParseMigrationFile(t *testing.T) {
	got, err := parseMigrationFile("/tmp/000002_create_aihub_skills.sql")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if got.Version != 2 {
		t.Fatalf("version=%d", got.Version)
	}
	if got.Name != "000002_create_aihub_skills.sql" {
		t.Fatalf("name=%s", got.Name)
	}
}

func TestParseMigrationFileRejectsInvalidName(t *testing.T) {
	if _, err := parseMigrationFile("create_aihub_skills.sql"); err == nil {
		t.Fatal("expected error")
	}
}

func TestConfigValidate(t *testing.T) {
	cfg := DefaultConfig()
	cfg.Enabled = true
	if err := cfg.Validate(); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	cfg.Table = "bad-name"
	if err := cfg.Validate(); err == nil {
		t.Fatal("expected invalid table error")
	}
}
