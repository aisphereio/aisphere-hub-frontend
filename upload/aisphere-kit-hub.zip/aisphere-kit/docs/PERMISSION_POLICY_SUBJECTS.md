# Permission policy subjects

`aisphere-kit/permission` is the only facade that business services should use
when they need to create, list, or revoke Casdoor/Casbin policies.

## Subject formats

Authorization checks from the Casdoor adapter use Casdoor's canonical user
subject format:

```text
<org>/<user>
```

Therefore policy writing must use the same format. New business code should use:

```go
permission.PolicySubject(subjectType, subjectID, orgID)
permission.PolicySubjectFromPrincipal(principal)
```

Examples:

```text
user + admin + aisphere       -> aisphere/admin
user + aisphere/test1 + empty -> aisphere/test1
service + agent-platform      -> service:agent-platform
agent + agent-001             -> agent:agent-001
public + empty                -> public:*
```

`permission.Subject` is kept for legacy code and returns `type:id`.

## Skill roles

The default role mapper includes canonical AIHub Skill roles:

- `viewer`: management/read-only view of one Skill.
- `consumer`: Agent/Runtime/Catalog consumption of one Skill.
- `editor`: viewer + write/update version/file actions.
- `owner`: editor + share/publish/delete actions.

Components can override the mapper with `permission.SetRoleActionMapper` when a
non-Skill resource needs a different role-to-action mapping.


## Simplified Casdoor dynamic sharing config

Business services should keep the Casdoor policy config small:

```yaml
casdoor:
  permission_id: aisphere/perm_aihub_admin
  policy_enforcer: enforcer_aisphere
  # Optional: defaults to aisphere/aisphere_policy_rule by convention.
  # policy_adapter_id: aisphere_policy_rule

  model_id: ""
  resource_id: ""
  enforcer_id: ""
  owner: ""
```

`permission_id` is used for global RBAC. `policy_enforcer` is used for dynamic
object-level share policies. A short `policy_enforcer` value is normalized to
`<organization>/<policy_enforcer>` for Enforce calls while policy write APIs still
receive Casdoor's `{owner, name}` enforcer object.

`policy_adapter_id` accepts either `owner/name` or a short adapter name. When it
is omitted, kit uses the platform default `aisphere_policy_rule` under the
configured Casdoor organization.
