// Package permission defines AI Sphere permission-management abstractions.
//
// The authority for permission decisions is expected to be Casdoor/Casbin via an
// implementation such as casdoor.Adapter. This package intentionally does not
// store permissions in local tables.
package permission

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/actionlab-ai/aisphere-kit/principal"
	"github.com/actionlab-ai/aisphere-kit/resource"
)

var (
	ErrManagerNil       = errors.New("permission manager is nil")
	ErrEmptySubject     = errors.New("permission subject is required")
	ErrEmptyResource    = errors.New("permission resource is required")
	ErrEmptyAction      = errors.New("permission action is required")
	ErrEmptyRole        = errors.New("permission role is required")
	ErrUnsupportedRole  = errors.New("unsupported permission role")
	ErrNotSupported     = errors.New("permission operation is not supported by current backend")
	ErrPermissionDenied = errors.New("permission denied")
)

const (
	SubjectUser     = "user"
	SubjectGroup    = "group"
	SubjectRole     = "role"
	SubjectOrg      = "org"
	SubjectProject  = "project"
	SubjectApp      = "app"
	SubjectService  = "service"
	SubjectAgent    = "agent"
	SubjectWorkflow = "workflow"
	SubjectRuntime  = "runtime"
	SubjectPublic   = "public"

	RoleViewer   = "viewer"
	RoleConsumer = "consumer"
	RoleEditor   = "editor"
	RoleOwner    = "owner"
)

// RoleActionMapper maps a resource + logical role to concrete Casbin actions.
// Components can replace the default mapper to support non-Skill resources such
// as agents, workflows, sandbox instances, or runtime sessions.
type RoleActionMapper func(resource.Name, string, []string) ([]string, error)

var roleMapper = struct {
	sync.RWMutex
	fn RoleActionMapper
}{fn: DefaultRoleActionMapper}

// SetRoleActionMapper replaces the process-wide role mapper. It is intended for
// application bootstrap code. Passing nil restores the default mapper.
func SetRoleActionMapper(fn RoleActionMapper) {
	roleMapper.Lock()
	defer roleMapper.Unlock()
	if fn == nil {
		roleMapper.fn = DefaultRoleActionMapper
		return
	}
	roleMapper.fn = fn
}

// DefaultRoleActionMapper keeps the canonical AIHub Skill role mapping. For
// non-Skill resources, callers should either pass explicit custom actions or
// install their own mapper at startup.
func DefaultRoleActionMapper(res resource.Name, role string, custom []string) ([]string, error) {
	if len(custom) > 0 {
		return cleanActions(custom), nil
	}
	switch role {
	case RoleViewer:
		return []string{
			"skill.read",
			"skill.version.list",
			"skill.version.read",
			"skill.file.list",
			"skill.file.read",
			"skill.compare",
			"skill.manifest.read",
		}, nil
	case RoleConsumer:
		return []string{
			"skill.catalog.read",
			"skill.consume",
			"skill.version.read",
			"skill.file.read",
			"skill.compare",
			"skill.manifest.read",
			"skill.download",
		}, nil
	case RoleEditor:
		return []string{
			"skill.read",
			"skill.version.list",
			"skill.version.read",
			"skill.file.list",
			"skill.file.read",
			"skill.compare",
			"skill.manifest.read",
			"skill.update",
			"skill.version.create",
			"skill.file.update",
			"skill.upload",
			"skill.submit",
			"skill.download",
		}, nil
	case RoleOwner:
		return []string{
			"skill.read",
			"skill.version.list",
			"skill.version.read",
			"skill.file.list",
			"skill.file.read",
			"skill.compare",
			"skill.manifest.read",
			"skill.catalog.read",
			"skill.consume",
			"skill.update",
			"skill.version.create",
			"skill.file.update",
			"skill.upload",
			"skill.submit",
			"skill.publish",
			"skill.force_publish",
			"skill.online",
			"skill.offline",
			"skill.download",
			"skill.share.list",
			"skill.share.create",
			"skill.share.delete",
			"skill.delete",
		}, nil
	case "":
		return nil, ErrEmptyRole
	default:
		return nil, fmt.Errorf("%w: %s", ErrUnsupportedRole, role)
	}
}

// Grant represents one logical permission grant. If Role is set, Actions may be
// empty and the manager can expand the role to one or more concrete actions.
type Grant struct {
	Subject     string         `json:"subject"`
	SubjectType string         `json:"subject_type,omitempty"`
	SubjectID   string         `json:"subject_id,omitempty"`
	OrgID       string         `json:"org_id,omitempty"`
	ProjectID   string         `json:"project_id,omitempty"`
	Resource    resource.Name  `json:"resource"`
	Action      string         `json:"action,omitempty"`
	Role        string         `json:"role,omitempty"`
	Actions     []string       `json:"actions,omitempty"`
	Domain      string         `json:"domain,omitempty"`
	GrantedBy   string         `json:"granted_by,omitempty"`
	ExpiresAt   *time.Time     `json:"expires_at,omitempty"`
	Metadata    map[string]any `json:"metadata,omitempty"`
}

type ShareRequest struct {
	Resource    resource.Name  `json:"resource"`
	SubjectType string         `json:"subject_type"`
	SubjectID   string         `json:"subject_id"`
	OrgID       string         `json:"org_id,omitempty"`
	ProjectID   string         `json:"project_id,omitempty"`
	Role        string         `json:"role"`
	Actions     []string       `json:"actions,omitempty"`
	Domain      string         `json:"domain,omitempty"`
	GrantedBy   string         `json:"granted_by,omitempty"`
	ExpiresAt   *time.Time     `json:"expires_at,omitempty"`
	Metadata    map[string]any `json:"metadata,omitempty"`
}

type CheckRequest struct {
	Subject   string               `json:"subject"`
	Principal *principal.Principal `json:"-"`
	Resource  resource.Name        `json:"resource"`
	Action    string               `json:"action"`
	Domain    string               `json:"domain,omitempty"`
	Extra     []any                `json:"extra,omitempty"`
}

type ListFilter struct {
	Subject  string        `json:"subject,omitempty"`
	Resource resource.Name `json:"resource,omitempty"`
	Action   string        `json:"action,omitempty"`
	Domain   string        `json:"domain,omitempty"`
}

type DeleteResourceRequest struct {
	Resource resource.Name `json:"resource"`
	Reason   string        `json:"reason,omitempty"`
	Actor    string        `json:"actor,omitempty"`
}

// Manager is the platform-level permission facade. Implementations should map
// these calls to Casdoor/Casbin policy APIs, not local business tables.
type Manager interface {
	Grant(ctx context.Context, grant Grant) error
	GrantRole(ctx context.Context, grant Grant) error
	Share(ctx context.Context, req ShareRequest) error
	Revoke(ctx context.Context, grant Grant) error
	Check(ctx context.Context, req CheckRequest) (bool, error)
	List(ctx context.Context, filter ListFilter) ([]Grant, error)
	DeleteResourcePolicies(ctx context.Context, resource resource.Name) error
	DeleteResourcePoliciesEx(ctx context.Context, req DeleteResourceRequest) error
}

// BackendValidator is implemented by managers that can fail fast when their
// backing policy store is misconfigured. Services should call it during startup
// when dynamic sharing/policy management is enabled.
type BackendValidator interface {
	ValidatePolicyBackend(ctx context.Context) error
}

// Subject returns the legacy subject format. New code that writes Casdoor/Casbin
// policies should prefer PolicySubject or PolicySubjectFromPrincipal so user
// grants match the same org/name subject used by Casdoor Authorize.
func Subject(subjectType, id string) string {
	subjectType = strings.TrimSpace(subjectType)
	id = strings.TrimSpace(id)
	if subjectType == "" {
		return id
	}
	if id == "" {
		return subjectType
	}
	return subjectType + ":" + id
}

// PolicySubject returns the subject string that should be written into Casbin
// policies. For users, it prefers Casdoor's canonical org/name format so the
// policies created by Manager.Share/Grant can be read by Authorize/Enforce.
func PolicySubject(subjectType, id, orgID string) string {
	subjectType = strings.TrimSpace(subjectType)
	id = strings.TrimSpace(id)
	orgID = strings.TrimSpace(orgID)
	if subjectType == "" {
		return id
	}
	if subjectType == SubjectPublic {
		if id == "" || id == "*" {
			return "public:*"
		}
		return "public:" + id
	}
	if id == "" {
		return subjectType
	}
	if subjectType == SubjectUser {
		if strings.Contains(id, "/") {
			return id
		}
		if orgID != "" {
			return orgID + "/" + id
		}
		return Subject(subjectType, id)
	}
	return Subject(subjectType, id)
}

func SubjectFromPrincipal(p *principal.Principal) string {
	if p == nil {
		return ""
	}
	return p.Subject()
}

// PolicySubjectFromPrincipal mirrors the subject formatting used by Casdoor
// authorization. Use it when listing or writing policies for the current actor.
func PolicySubjectFromPrincipal(p *principal.Principal) string {
	if p == nil {
		return ""
	}
	if p.SubjectType == principal.SubjectUser {
		if p.OrgID != "" && p.SubjectID != "" {
			return strings.TrimSpace(p.OrgID) + "/" + strings.TrimSpace(p.SubjectID)
		}
		if subject, ok := p.Claims["subject"].(string); ok {
			if subject = strings.TrimSpace(subject); subject != "" {
				return subject
			}
		}
	}
	return p.Subject()
}

func NormalizeGrant(g Grant) (Grant, error) {
	if g.Subject == "" && g.SubjectType != "" {
		g.Subject = PolicySubject(g.SubjectType, g.SubjectID, g.OrgID)
	}
	g.Subject = strings.TrimSpace(g.Subject)
	g.Action = strings.TrimSpace(g.Action)
	g.Role = strings.TrimSpace(g.Role)
	if g.Subject == "" {
		return g, ErrEmptySubject
	}
	if g.Resource.String() == "" {
		return g, ErrEmptyResource
	}
	if g.Action == "" && g.Role == "" && len(g.Actions) == 0 {
		return g, ErrEmptyAction
	}
	if g.ExpiresAt != nil {
		// Casbin p, sub, obj, act policies are intentionally timeless in v1.
		// Expiring share links should be modeled in the business component and
		// materialized/revoked through this manager when accepted/expired.
		return g, fmt.Errorf("%w: expires_at on Casbin policy grant", ErrNotSupported)
	}
	return g, nil
}

func NormalizeShare(req ShareRequest) (Grant, error) {
	if req.SubjectType == "" {
		return Grant{}, ErrEmptySubject
	}
	if req.SubjectType != SubjectPublic && req.SubjectID == "" {
		return Grant{}, ErrEmptySubject
	}
	if req.Resource.String() == "" {
		return Grant{}, ErrEmptyResource
	}
	if req.Role == "" && len(req.Actions) == 0 {
		return Grant{}, ErrEmptyRole
	}
	return NormalizeGrant(Grant{
		Subject:     PolicySubject(req.SubjectType, req.SubjectID, req.OrgID),
		SubjectType: req.SubjectType,
		SubjectID:   req.SubjectID,
		OrgID:       req.OrgID,
		ProjectID:   req.ProjectID,
		Resource:    req.Resource,
		Role:        req.Role,
		Actions:     req.Actions,
		Domain:      req.Domain,
		GrantedBy:   req.GrantedBy,
		ExpiresAt:   req.ExpiresAt,
		Metadata:    req.Metadata,
	})
}

func RoleActions(role string, custom []string) ([]string, error) {
	return RoleActionsForResource("", role, custom)
}

func RoleActionsForResource(res resource.Name, role string, custom []string) ([]string, error) {
	roleMapper.RLock()
	fn := roleMapper.fn
	roleMapper.RUnlock()
	if fn == nil {
		fn = DefaultRoleActionMapper
	}
	return fn(res, role, custom)
}

func cleanActions(in []string) []string {
	out := make([]string, 0, len(in))
	seen := map[string]struct{}{}
	for _, a := range in {
		a = strings.TrimSpace(a)
		if a == "" {
			continue
		}
		if _, ok := seen[a]; ok {
			continue
		}
		seen[a] = struct{}{}
		out = append(out, a)
	}
	return out
}

func Require(ctx context.Context, mgr Manager, req CheckRequest) error {
	if mgr == nil {
		return ErrManagerNil
	}
	if req.Subject == "" && req.Principal != nil {
		req.Subject = PolicySubjectFromPrincipal(req.Principal)
	}
	if req.Subject == "" {
		return ErrEmptySubject
	}
	if req.Resource.String() == "" {
		return ErrEmptyResource
	}
	if req.Action == "" {
		return ErrEmptyAction
	}
	ok, err := mgr.Check(ctx, req)
	if err != nil {
		return err
	}
	if !ok {
		return ErrPermissionDenied
	}
	return nil
}
