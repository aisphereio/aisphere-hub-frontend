package permission

import (
	"testing"

	"github.com/actionlab-ai/aisphere-kit/resource"
)

func TestSubject(t *testing.T) {
	if got := Subject(SubjectUser, "alice"); got != "user:alice" {
		t.Fatalf("unexpected subject: %s", got)
	}
}

func TestNormalizeShareKeepsLegacyUserSubjectWithoutOrg(t *testing.T) {
	g, err := NormalizeShare(ShareRequest{Resource: resource.AIHubSkill("s1"), SubjectType: SubjectUser, SubjectID: "alice", Role: RoleViewer})
	if err != nil {
		t.Fatal(err)
	}
	if g.Subject != "user:alice" || g.Resource.String() != "aihub:skill:s1" {
		t.Fatalf("bad grant: %+v", g)
	}
}

func TestNormalizeShareUsesCasdoorUserSubjectWithOrg(t *testing.T) {
	g, err := NormalizeShare(ShareRequest{Resource: resource.AIHubSkill("s1"), SubjectType: SubjectUser, SubjectID: "alice", OrgID: "aisphere", Role: RoleViewer})
	if err != nil {
		t.Fatal(err)
	}
	if g.Subject != "aisphere/alice" || g.Resource.String() != "aihub:skill:s1" {
		t.Fatalf("bad grant: %+v", g)
	}
}

func TestPolicySubjectSupportsCrossPlatformSubjects(t *testing.T) {
	cases := map[string]string{
		PolicySubject(SubjectService, "agent-platform", ""): "service:agent-platform",
		PolicySubject(SubjectAgent, "agent-001", ""):        "agent:agent-001",
		PolicySubject(SubjectPublic, "", ""):                "public:*",
	}
	for got, want := range cases {
		if got != want {
			t.Fatalf("PolicySubject() = %q, want %q", got, want)
		}
	}
}

func TestDefaultRoleActionMapperIncludesSkillLifecycleActions(t *testing.T) {
	actions, err := DefaultRoleActionMapper("aihub:skill:demo", RoleOwner, nil)
	if err != nil {
		t.Fatalf("DefaultRoleActionMapper() error = %v", err)
	}
	for _, want := range []string{
		"skill.submit",
		"skill.publish",
		"skill.force_publish",
		"skill.online",
		"skill.offline",
		"skill.download",
		"skill.compare",
		"skill.manifest.read",
	} {
		if !containsAction(actions, want) {
			t.Fatalf("owner actions missing %q: %#v", want, actions)
		}
	}
}

func containsAction(actions []string, want string) bool {
	for _, action := range actions {
		if action == want {
			return true
		}
	}
	return false
}

func TestRoleActions(t *testing.T) {
	actions, err := RoleActions(RoleOwner, nil)
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, a := range actions {
		if a == "skill.share.create" {
			found = true
		}
	}
	if !found {
		t.Fatalf("owner role should include skill.share.create: %#v", actions)
	}
}
