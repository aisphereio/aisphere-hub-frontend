package starter

import (
	"context"
	"fmt"
	"log/slog"
	"time"

	"github.com/actionlab-ai/aisphere-kit/access"
	"github.com/actionlab-ai/aisphere-kit/audit"
	"github.com/actionlab-ai/aisphere-kit/authn"
	"github.com/actionlab-ai/aisphere-kit/authz"
	"github.com/actionlab-ai/aisphere-kit/cache"
	"github.com/actionlab-ai/aisphere-kit/casdoor"
	"github.com/actionlab-ai/aisphere-kit/config"
	"github.com/actionlab-ai/aisphere-kit/db"
	"github.com/actionlab-ai/aisphere-kit/logx"
	"github.com/actionlab-ai/aisphere-kit/metrics"
	"github.com/actionlab-ai/aisphere-kit/migration"
	"github.com/actionlab-ai/aisphere-kit/objectstore"
	"github.com/actionlab-ai/aisphere-kit/permission"
	"github.com/actionlab-ai/aisphere-kit/session"
	"github.com/redis/go-redis/v9"
	"gorm.io/gorm"
)

type Runtime struct {
	Config   *config.Config
	Logger   *slog.Logger
	DB       *gorm.DB
	Database db.Database
	// Deprecated: use Database. Kept for compatibility with older services.
	SQL          db.Database
	Redis        redis.UniversalClient
	RedisRuntime *cache.Redis
	S3           objectstore.Client
	Casdoor      *casdoor.Adapter
	Authn        authn.Authenticator
	Authz        authz.Authorizer
	Audit        audit.Recorder
	Access       *access.Guard
	Session      *session.Manager
	Tx           *db.TxManager
	Permission   permission.Manager
	Metrics      *metrics.Metrics
	Migration    *migration.Runner
}

type RuntimeOption func(*Runtime)

func NewRuntime(ctx context.Context, cfg *config.Config, opts ...RuntimeOption) (*Runtime, func() error, error) {
	cleanups := &CleanupStack{}
	logger := logx.New(cfg.Log).With("app", cfg.App.Name, "env", cfg.App.Env, "version", cfg.App.Version)
	rt := &Runtime{Config: cfg, Logger: logger}
	for _, opt := range opts {
		if opt != nil {
			opt(rt)
		}
	}
	ctx = logx.NewContext(ctx, rt.Logger)
	startedAll := time.Now()
	rt.Logger.Info("aisphere runtime init started", "features", cfg.Features)
	defer func() {
		rt.Logger.Debug("aisphere runtime init defer reached", "elapsed", time.Since(startedAll).String())
	}()
	if cfg.Features.Metrics {
		started := time.Now()
		rt.Logger.Debug("metrics init started")
		m, err := metrics.New(cfg.Metrics, cfg.App.Name)
		if err != nil {
			_ = cleanups.Close()
			rt.Logger.Error("metrics init failed", "error", err)
			return nil, nil, fmt.Errorf("init metrics: %w", err)
		}
		rt.Metrics = m
		rt.Logger.Info("metrics init completed", "elapsed", time.Since(started).String())
	} else {
		rt.Logger.Info("metrics disabled")
	}
	if cfg.Features.DB {
		sqldb, err := db.NewDatabase(ctx, cfg.Database, db.WithLogger(rt.Logger), db.WithMetrics(rt.Metrics))
		if err != nil {
			_ = cleanups.Close()
			return nil, nil, err
		}
		rt.Database = sqldb
		rt.SQL = sqldb
		rt.DB = sqldb.GORM()
		rt.Tx = db.NewTxManager(sqldb.GORM(), rt.Logger)
		cleanups.Add(sqldb.Close)
		if cfg.Migration.Enabled {
			started := time.Now()
			rt.Logger.Debug("migration runner init started", "auto_apply", cfg.Migration.AutoApply, "path", cfg.Migration.Normalized().Path)
			runner, err := migration.NewRunner(rt.DB, cfg.Migration, migration.WithLogger(rt.Logger))
			if err != nil {
				_ = cleanups.Close()
				rt.Logger.Error("migration runner init failed", "error", err)
				return nil, nil, fmt.Errorf("init migration runner: %w", err)
			}
			rt.Migration = runner
			if cfg.Migration.AutoApply {
				rt.Logger.Info("migration auto apply started")
				if err := runner.Up(ctx); err != nil {
					_ = cleanups.Close()
					rt.Logger.Error("migration auto apply failed", "error", err)
					return nil, nil, fmt.Errorf("auto apply migrations: %w", err)
				}
				rt.Logger.Info("migration auto apply completed", "elapsed", time.Since(started).String())
			} else {
				rt.Logger.Info("migration runner ready", "auto_apply", false, "elapsed", time.Since(started).String())
			}
		} else {
			rt.Logger.Info("migration disabled")
		}
	} else {
		rt.Logger.Info("database disabled")
	}
	if cfg.Features.Cache {
		r, err := cache.NewRedis(ctx, cfg.Redis, cache.WithLogger(rt.Logger), cache.WithMetrics(rt.Metrics))
		if err != nil {
			_ = cleanups.Close()
			return nil, nil, err
		}
		rt.RedisRuntime = r
		rt.Redis = r.Client
		if cfg.Features.Session {
			rt.Session = session.NewManager(r.Client, cfg.Session, session.WithLogger(rt.Logger))
		}
		cleanups.Add(r.Close)
	} else {
		rt.Logger.Info("redis disabled")
	}
	if cfg.Features.S3 {
		s3, err := objectstore.NewMinIO(ctx, cfg.ObjectStore, objectstore.WithLogger(rt.Logger), objectstore.WithMetrics(rt.Metrics))
		if err != nil {
			_ = cleanups.Close()
			return nil, nil, err
		}
		rt.S3 = s3
	} else {
		rt.Logger.Info("objectstore disabled")
	}
	if cfg.Features.Authn || cfg.Features.Authz || cfg.Features.Audit || cfg.Features.Permission {
		started := time.Now()
		rt.Logger.Debug("casdoor init started", "authn", cfg.Features.Authn, "authz", cfg.Features.Authz, "audit", cfg.Features.Audit, "permission", cfg.Features.Permission)
		var adapter *casdoor.Adapter
		var err error
		if cfg.Features.Authn {
			adapter, err = casdoor.NewChecked(cfg.Casdoor, casdoor.WithLogger(rt.Logger), casdoor.WithMetrics(rt.Metrics))
		} else {
			adapter = casdoor.New(cfg.Casdoor, casdoor.WithLogger(rt.Logger), casdoor.WithMetrics(rt.Metrics))
		}
		if err != nil {
			_ = cleanups.Close()
			rt.Logger.Error("casdoor init failed", "error", err)
			return nil, nil, fmt.Errorf("init casdoor: %w", err)
		}
		rt.Casdoor = adapter
		if cfg.Features.Authn {
			rt.Authn = rt.Casdoor
		}
		if cfg.Features.Authz {
			rt.Authz = rt.Casdoor
		}
		if cfg.Features.Audit {
			rt.Audit = rt.Casdoor
		}
		if cfg.Features.Permission {
			rt.Permission = rt.Casdoor
			if validator, ok := rt.Permission.(permission.BackendValidator); ok {
				if err := validator.ValidatePolicyBackend(ctx); err != nil {
					_ = cleanups.Close()
					rt.Logger.Error("casdoor permission backend validation failed", "error", err)
					return nil, nil, fmt.Errorf("validate casdoor permission backend: %w", err)
				}
			}
		}
		rt.Logger.Info("casdoor init completed", "elapsed", time.Since(started).String())
	} else {
		rt.Logger.Info("casdoor disabled")
	}
	rt.Access = access.NewGuard(access.Options{
		Authz:        rt.Authz,
		Audit:        rt.Audit,
		AuthzEnabled: cfg.Features.Authz,
		AuditEnabled: cfg.Features.Audit,
		Logger:       rt.Logger,
		Component:    cfg.App.Name,
	})
	rt.Logger.Info("access guard initialized", "authz_enabled", cfg.Features.Authz, "authz_configured", rt.Authz != nil, "audit_enabled", cfg.Features.Audit, "audit_configured", rt.Audit != nil)
	rt.Logger.Info("aisphere runtime init completed", "elapsed", time.Since(startedAll).String())
	return rt, cleanups.Close, nil
}

func (rt *Runtime) WithTx(ctx context.Context, fn func(ctx context.Context, tx *gorm.DB) error) error {
	if rt == nil || rt.Tx == nil {
		return fmt.Errorf("runtime transaction manager is nil")
	}
	return rt.Tx.WithTx(ctx, fn)
}

func (rt *Runtime) DBFromContext(ctx context.Context) *gorm.DB {
	if rt == nil || rt.Tx == nil {
		return nil
	}
	return rt.Tx.DB(ctx)
}
