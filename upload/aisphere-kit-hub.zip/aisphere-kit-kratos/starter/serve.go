package starter

import (
	"context"
	"fmt"
	"os"
	"time"

	kitconfig "github.com/actionlab-ai/aisphere-kit/config"
	kitlog "github.com/actionlab-ai/aisphere-kit/logx"
	kitstarter "github.com/actionlab-ai/aisphere-kit/starter"
	"github.com/go-kratos/kratos/v3"
)

type AppFactory func(ctx context.Context, cfg *kitconfig.Config, rt *kitstarter.Runtime) (*kratos.App, func(), error)

type ServeOptions struct {
	ConfigPaths    []string
	RuntimeOptions []kitstarter.RuntimeOption
	NewApp         AppFactory
}

func Serve(ctx context.Context, opt ServeOptions) error {
	if opt.NewApp == nil {
		return fmt.Errorf("kratos app factory is nil")
	}
	cfg, rt, cleanup, err := kitstarter.NewRuntimeFromConfig(ctx, opt.ConfigPaths, opt.RuntimeOptions...)
	if err != nil {
		return err
	}
	logger := rt.Logger
	ctx = kitlog.NewContext(ctx, logger)
	logger.Info("kratos service runtime ready", "app", cfg.App.Name, "env", cfg.App.Env, "version", cfg.App.Version)
	app, appCleanup, err := opt.NewApp(ctx, cfg, rt)
	if err != nil {
		_ = cleanup()
		logger.Error("kratos app factory failed", "error", err)
		return err
	}
	stopTimeout := kitconfig.ParseDurationOr(cfg.Shutdown.Timeout, 15*time.Second)
	if app == nil {
		_ = cleanup()
		return fmt.Errorf("kratos app factory returned nil app")
	}
	logger.Info("kratos app starting", "stop_timeout", stopTimeout.String())
	runErr := app.Run()
	logger.Info("kratos app stopped", "error", runErr)
	if appCleanup != nil {
		if err := kitstarter.CleanupWithTimeout(func() error { appCleanup(); return nil }, stopTimeout); err != nil {
			logger.Warn("kratos app cleanup failed", "error", err)
		}
	}
	if cleanup != nil {
		if err := kitstarter.CleanupWithTimeout(cleanup, stopTimeout); err != nil {
			logger.Warn("runtime cleanup failed", "error", err)
		}
	}
	return runErr
}

func MustServe(ctx context.Context, opt ServeOptions) {
	if err := Serve(ctx, opt); err != nil {
		_, _ = fmt.Fprintf(os.Stderr, "aisphere kratos service failed: %v\n", err)
		os.Exit(1)
	}
}
