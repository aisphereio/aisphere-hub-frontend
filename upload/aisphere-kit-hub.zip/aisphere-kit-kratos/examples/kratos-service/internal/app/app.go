package app

import (
	"context"
	"time"

	"github.com/actionlab-ai/aisphere-kit-kratos/kratosx"
	kitconfig "github.com/actionlab-ai/aisphere-kit/config"
	kitstarter "github.com/actionlab-ai/aisphere-kit/starter"
	"github.com/go-kratos/kratos/v3"
)

func NewApp(ctx context.Context, cfg *kitconfig.Config, rt *kitstarter.Runtime) (*kratos.App, func(), error) {
	httpSrv := kratosx.NewHTTPServer(cfg, rt)
	grpcSrv := kratosx.NewGRPCServer(cfg, rt)
	app := kratos.New(
		kratos.Context(ctx),
		kratos.Name(cfg.App.Name),
		kratos.Version(cfg.App.Version),
		kratos.Logger(rt.Logger),
		kratos.StopTimeout(kitconfig.ParseDurationOr(cfg.Shutdown.Timeout, 15*time.Second)),
		kratos.Server(httpSrv, grpcSrv),
	)
	return app, func() {}, nil
}
