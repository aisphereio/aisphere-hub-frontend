module github.com/actionlab-ai/aisphere-kit-kratos/examples/kratos-service

go 1.25
