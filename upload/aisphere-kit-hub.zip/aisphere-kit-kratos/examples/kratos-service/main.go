package main

import (
	"context"

	"github.com/actionlab-ai/aisphere-kit-kratos/examples/kratos-service/internal/app"
	kratosstarter "github.com/actionlab-ai/aisphere-kit-kratos/starter"
)

func main() {
	kratosstarter.MustServe(context.Background(), kratosstarter.ServeOptions{
		ConfigPaths: []string{"configs/config.yaml"},
		NewApp:      app.NewApp,
	})
}
