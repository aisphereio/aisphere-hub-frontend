package kratosx

import (
	"context"
	"encoding/json"
	stdhttp "net/http"
	"time"

	kitmw "github.com/actionlab-ai/aisphere-kit-kratos/middleware"
	kitconfig "github.com/actionlab-ai/aisphere-kit/config"
	"github.com/actionlab-ai/aisphere-kit/health"
	kitlog "github.com/actionlab-ai/aisphere-kit/logx"
	kitstarter "github.com/actionlab-ai/aisphere-kit/starter"
	kgrpc "github.com/go-kratos/kratos/v3/transport/grpc"
	khttp "github.com/go-kratos/kratos/v3/transport/http"
)

type ServerOptions struct {
	Middlewares []kitmw.ChainOption
	HTTPOptions []khttp.ServerOption
	GRPCOptions []kgrpc.ServerOption
	Health      bool
}

type ServerOption func(*ServerOptions)

func WithMiddlewares(opts ...kitmw.ChainOption) ServerOption {
	return func(o *ServerOptions) { o.Middlewares = append(o.Middlewares, opts...) }
}
func WithHTTPOptions(opts ...khttp.ServerOption) ServerOption {
	return func(o *ServerOptions) { o.HTTPOptions = append(o.HTTPOptions, opts...) }
}
func WithGRPCOptions(opts ...kgrpc.ServerOption) ServerOption {
	return func(o *ServerOptions) { o.GRPCOptions = append(o.GRPCOptions, opts...) }
}
func WithHealthHandlers(v bool) ServerOption { return func(o *ServerOptions) { o.Health = v } }

func NewHTTPServer(cfg *kitconfig.Config, rt *kitstarter.Runtime, opts ...ServerOption) *khttp.Server {
	o := ServerOptions{Health: true}
	for _, opt := range opts {
		if opt != nil {
			opt(&o)
		}
	}
	addr := cfg.Server.HTTP.Addr
	if addr == "" {
		addr = "0.0.0.0:8000"
	}
	timeout := kitconfig.ParseDurationOr(cfg.Server.HTTP.Timeout, 10*time.Second)
	mw := kitmw.DefaultMiddlewares(rt, o.Middlewares...)
	httpOpts := []khttp.ServerOption{khttp.Address(addr), khttp.Timeout(timeout), khttp.Middleware(mw...)}
	httpOpts = append(httpOpts, o.HTTPOptions...)
	srv := khttp.NewServer(httpOpts...)
	if o.Health {
		RegisterHealthHandlers(srv, rt)
	}
	if rt != nil && rt.Logger != nil {
		rt.Logger.Info("kratos http server created", "addr", addr, "timeout", timeout.String(), "health", o.Health)
	}
	return srv
}

func NewGRPCServer(cfg *kitconfig.Config, rt *kitstarter.Runtime, opts ...ServerOption) *kgrpc.Server {
	o := ServerOptions{}
	for _, opt := range opts {
		if opt != nil {
			opt(&o)
		}
	}
	addr := cfg.Server.GRPC.Addr
	if addr == "" {
		addr = "0.0.0.0:9000"
	}
	timeout := kitconfig.ParseDurationOr(cfg.Server.GRPC.Timeout, 10*time.Second)
	mw := kitmw.DefaultMiddlewares(rt, o.Middlewares...)
	grpcOpts := []kgrpc.ServerOption{kgrpc.Address(addr), kgrpc.Timeout(timeout), kgrpc.Middleware(mw...)}
	grpcOpts = append(grpcOpts, o.GRPCOptions...)
	srv := kgrpc.NewServer(grpcOpts...)
	if rt != nil && rt.Logger != nil {
		rt.Logger.Info("kratos grpc server created", "addr", addr, "timeout", timeout.String())
	}
	return srv
}

func RegisterHealthHandlers(srv *khttp.Server, rt *kitstarter.Runtime) {
	if srv == nil {
		return
	}
	srv.HandleFunc("/livez", func(w stdhttp.ResponseWriter, r *stdhttp.Request) {
		writeHealth(w, health.Live(healthContext(r, rt), rt))
	})
	srv.HandleFunc("/readyz", func(w stdhttp.ResponseWriter, r *stdhttp.Request) {
		results := health.Check(healthContext(r, rt), rt)
		if err := health.IsHealthy(results); err != nil {
			w.WriteHeader(stdhttp.StatusServiceUnavailable)
		}
		writeHealth(w, results)
	})
}

func healthContext(r *stdhttp.Request, rt *kitstarter.Runtime) context.Context {
	if rt != nil && rt.Logger != nil {
		return kitlog.NewContext(r.Context(), rt.Logger)
	}
	return r.Context()
}

func writeHealth(w stdhttp.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(v)
}
