package middleware

import (
	"context"
	"log/slog"

	"github.com/actionlab-ai/aisphere-kit/authz"
	kitlog "github.com/actionlab-ai/aisphere-kit/logx"
	"github.com/actionlab-ai/aisphere-kit/principal"
	"github.com/go-kratos/kratos/v3/middleware"
)

type AuthzResolver func(ctx context.Context, req any) (resource string, action string, err error)

type AuthzOptions struct {
	Resolver   AuthzResolver
	AllowEmpty bool
	Logger     *slog.Logger
	Skip       func(ctx context.Context, req any) bool
}

type AuthzOption func(*AuthzOptions)

func WithAuthzResolver(fn AuthzResolver) AuthzOption {
	return func(o *AuthzOptions) { o.Resolver = fn }
}
func WithAuthzAllowEmpty(v bool) AuthzOption     { return func(o *AuthzOptions) { o.AllowEmpty = v } }
func WithAuthzLogger(l *slog.Logger) AuthzOption { return func(o *AuthzOptions) { o.Logger = l } }
func WithAuthzSkip(fn func(context.Context, any) bool) AuthzOption {
	return func(o *AuthzOptions) { o.Skip = fn }
}

func Authz(a authz.Authorizer, opts ...AuthzOption) middleware.Middleware {
	o := AuthzOptions{}
	for _, opt := range opts {
		if opt != nil {
			opt(&o)
		}
	}
	return func(next middleware.Handler) middleware.Handler {
		return func(ctx context.Context, req any) (any, error) {
			if o.Skip != nil && o.Skip(ctx, req) {
				return next(ctx, req)
			}
			logger := o.Logger
			if logger == nil {
				logger = kitlog.FromContext(ctx)
			}
			if o.Resolver == nil {
				logger.Debug("authz resolver missing; skipping middleware authz", "operation", operation(ctx))
				return next(ctx, req)
			}
			res, act, err := o.Resolver(ctx, req)
			if err != nil {
				logger.Warn("authz resolver failed", "error", err, "operation", operation(ctx))
				return nil, wrapForbidden(err)
			}
			if res == "" || act == "" {
				if o.AllowEmpty {
					logger.Debug("authz empty resource/action allowed", "operation", operation(ctx), "resource", res, "action", act)
					return next(ctx, req)
				}
				err := authz.ErrEmptyAuthorization
				logger.Warn("authz empty resource/action denied", "operation", operation(ctx), "resource", res, "action", act)
				return nil, wrapForbidden(err)
			}
			p, err := principal.RequireFromContext(ctx)
			if err != nil {
				logger.Warn("authz principal missing", "error", err, "operation", operation(ctx))
				return nil, wrapUnauthorized(err)
			}
			if err := authz.RequirePrincipal(ctx, a, p, res, act); err != nil {
				logger.Warn("authz denied", "error", err, "operation", operation(ctx), "subject", p.Subject(), "resource", res, "action", act)
				return nil, wrapForbidden(err)
			}
			logger.Debug("authz allowed", "operation", operation(ctx), "subject", p.Subject(), "resource", res, "action", act)
			return next(ctx, req)
		}
	}
}
