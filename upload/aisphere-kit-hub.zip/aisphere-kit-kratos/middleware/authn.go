package middleware

import (
	"context"
	"log/slog"

	"github.com/actionlab-ai/aisphere-kit/authn"
	kitlog "github.com/actionlab-ai/aisphere-kit/logx"
	"github.com/actionlab-ai/aisphere-kit/session"
	"github.com/go-kratos/kratos/v3/middleware"
)

type AuthnOptions struct {
	AllowAnonymous bool
	Session        *session.Manager
	Logger         *slog.Logger
	Skip           func(ctx context.Context, req any) bool
}

type AuthnOption func(*AuthnOptions)

func WithAllowAnonymous(v bool) AuthnOption      { return func(o *AuthnOptions) { o.AllowAnonymous = v } }
func WithSession(m *session.Manager) AuthnOption { return func(o *AuthnOptions) { o.Session = m } }
func WithAuthnLogger(l *slog.Logger) AuthnOption { return func(o *AuthnOptions) { o.Logger = l } }
func WithAuthnSkip(fn func(context.Context, any) bool) AuthnOption {
	return func(o *AuthnOptions) { o.Skip = fn }
}

func Authn(a authn.Authenticator, opts ...AuthnOption) middleware.Middleware {
	o := AuthnOptions{}
	for _, opt := range opts {
		if opt != nil {
			opt(&o)
		}
	}
	return func(next middleware.Handler) middleware.Handler {
		return func(ctx context.Context, req any) (any, error) {
			if o.Skip != nil && o.Skip(ctx, req) {
				return next(ctx, req)
			}
			logger := o.Logger
			if logger == nil {
				logger = kitlog.FromContext(ctx)
			}
			token := authToken(ctx)
			if o.Session != nil && token != "" {
				revoked, err := o.Session.IsRevoked(ctx, token)
				if err != nil {
					logger.Warn("authn token blacklist check failed", "error", err, "operation", operation(ctx))
					return nil, wrapUnauthorized(err)
				}
				if revoked {
					logger.Warn("authn token revoked", "operation", operation(ctx))
					return nil, wrapUnauthorized(ErrTokenRevoked)
				}
			}
			ctx2, p, err := authn.AuthenticateToken(ctx, a, token, o.AllowAnonymous)
			if err != nil {
				logger.Warn("authn failed", "error", err, "operation", operation(ctx), "has_token", token != "")
				return nil, wrapUnauthorized(err)
			}
			logger.Debug("authn completed", "operation", operation(ctx), "subject", p.Subject(), "anonymous", !p.IsAuthenticated())
			return next(ctx2, req)
		}
	}
}
