package middleware

import (
	"context"
	"crypto/rand"
	"encoding/hex"

	kitlog "github.com/actionlab-ai/aisphere-kit/logx"
	"github.com/go-kratos/kratos/v3/middleware"
)

type RequestIDOptions struct {
	Generator func() string
}

type RequestIDOption func(*RequestIDOptions)

func WithRequestIDGenerator(fn func() string) RequestIDOption {
	return func(o *RequestIDOptions) { o.Generator = fn }
}

func RequestID(opts ...RequestIDOption) middleware.Middleware {
	o := RequestIDOptions{Generator: randomID}
	for _, opt := range opts {
		if opt != nil {
			opt(&o)
		}
	}
	return func(next middleware.Handler) middleware.Handler {
		return func(ctx context.Context, req any) (any, error) {
			id := requestID(ctx)
			if id == "" && o.Generator != nil {
				id = o.Generator()
			}
			ctx = kitlog.WithRequestID(ctx, id)
			return next(ctx, req)
		}
	}
}

func randomID() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return ""
	}
	return hex.EncodeToString(b)
}
