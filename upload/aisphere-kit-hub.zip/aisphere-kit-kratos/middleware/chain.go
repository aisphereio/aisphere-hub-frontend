package middleware

import (
	"context"

	kitstarter "github.com/actionlab-ai/aisphere-kit/starter"
	kmw "github.com/go-kratos/kratos/v3/middleware"
	"github.com/go-kratos/kratos/v3/middleware/recovery"
)

type ChainOptions struct {
	AllowAnonymous bool
	AuthzResolver  AuthzResolver
	AuditResolver  AuditResolver
	AuditAsync     bool
	AuditSkip      func(ctx context.Context, req any) bool
	AuthnSkip      func(ctx context.Context, req any) bool
	AuthzSkip      func(ctx context.Context, req any) bool
	Extra          []kmw.Middleware
}

type ChainOption func(*ChainOptions)

func WithChainAllowAnonymous(v bool) ChainOption {
	return func(o *ChainOptions) { o.AllowAnonymous = v }
}
func WithChainAuthzResolver(fn AuthzResolver) ChainOption {
	return func(o *ChainOptions) { o.AuthzResolver = fn }
}
func WithChainAuditResolver(fn AuditResolver) ChainOption {
	return func(o *ChainOptions) { o.AuditResolver = fn }
}
func WithChainAuditAsync(v bool) ChainOption { return func(o *ChainOptions) { o.AuditAsync = v } }
func WithChainExtra(m ...kmw.Middleware) ChainOption {
	return func(o *ChainOptions) { o.Extra = append(o.Extra, m...) }
}
func WithChainAuthnSkip(fn func(context.Context, any) bool) ChainOption {
	return func(o *ChainOptions) { o.AuthnSkip = fn }
}
func WithChainAuthzSkip(fn func(context.Context, any) bool) ChainOption {
	return func(o *ChainOptions) { o.AuthzSkip = fn }
}
func WithChainAuditSkip(fn func(context.Context, any) bool) ChainOption {
	return func(o *ChainOptions) { o.AuditSkip = fn }
}

func DefaultMiddlewares(rt *kitstarter.Runtime, opts ...ChainOption) []kmw.Middleware {
	o := ChainOptions{}
	for _, opt := range opts {
		if opt != nil {
			opt(&o)
		}
	}
	out := []kmw.Middleware{recovery.Recovery(), RequestID()}
	out = append(out, o.Extra...)
	if rt != nil && rt.Authn != nil {
		out = append(out, Authn(rt.Authn, WithAllowAnonymous(o.AllowAnonymous), WithSession(rt.Session), WithAuthnLogger(rt.Logger), WithAuthnSkip(o.AuthnSkip)))
	}
	if rt != nil && rt.Authz != nil && o.AuthzResolver != nil {
		out = append(out, Authz(rt.Authz, WithAuthzResolver(o.AuthzResolver), WithAuthzLogger(rt.Logger), WithAuthzSkip(o.AuthzSkip)))
	}
	if rt != nil && rt.Metrics != nil {
		out = append(out, Metrics(rt.Metrics))
	}
	if rt != nil && rt.Audit != nil {
		out = append(out, Audit(rt.Audit, WithAuditComponent(rt.Config.App.Name), WithAuditResolver(o.AuditResolver), WithAuditAsync(o.AuditAsync), WithAuditLogger(rt.Logger), WithAuditSkip(o.AuditSkip)))
	}
	return out
}
