package middleware

import (
	"context"
	"time"

	kitmetrics "github.com/actionlab-ai/aisphere-kit/metrics"
	"github.com/go-kratos/kratos/v3/middleware"
)

func Metrics(m *kitmetrics.Metrics) middleware.Middleware {
	return func(next middleware.Handler) middleware.Handler {
		return func(ctx context.Context, req any) (any, error) {
			started := time.Now()
			reply, err := next(ctx, req)
			if m != nil {
				m.Observe(operation(ctx), statusCode(err), started)
			}
			return reply, err
		}
	}
}
