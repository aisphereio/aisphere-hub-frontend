package middleware

import (
	"context"
	"errors"
	"strings"

	kitlog "github.com/actionlab-ai/aisphere-kit/logx"
	kerrors "github.com/go-kratos/kratos/v3/errors"
	"github.com/go-kratos/kratos/v3/transport"
)

const (
	HeaderAuthorization = "Authorization"
	HeaderRequestID     = "X-Request-Id"
	HeaderRequestIDAlt  = "X-Request-ID"
)

var (
	ErrTokenRevoked = errors.New("token revoked")
)

func operation(ctx context.Context) string {
	if tr, ok := transport.FromServerContext(ctx); ok && tr != nil {
		return tr.Operation()
	}
	return "unknown"
}

func requestHeader(ctx context.Context, key string) string {
	if tr, ok := transport.FromServerContext(ctx); ok && tr != nil && tr.RequestHeader() != nil {
		return tr.RequestHeader().Get(key)
	}
	return ""
}

func requestID(ctx context.Context) string {
	if id := kitlog.RequestID(ctx); id != "" {
		return id
	}
	if id := requestHeader(ctx, HeaderRequestID); id != "" {
		return id
	}
	if id := requestHeader(ctx, HeaderRequestIDAlt); id != "" {
		return id
	}
	return ""
}

func authToken(ctx context.Context) string {
	header := requestHeader(ctx, HeaderAuthorization)
	header = strings.TrimSpace(header)
	if header == "" {
		return ""
	}
	parts := strings.SplitN(header, " ", 2)
	if len(parts) == 2 && strings.EqualFold(parts[0], "Bearer") {
		return strings.TrimSpace(parts[1])
	}
	return ""
}

func statusCode(err error) int {
	if err == nil {
		return 200
	}
	code := kerrors.Code(err)
	if code == 0 {
		return 500
	}
	return code
}

func wrapUnauthorized(err error) error {
	if err == nil {
		return nil
	}
	return kerrors.Unauthorized("UNAUTHORIZED", err.Error()).WithCause(err)
}

func wrapForbidden(err error) error {
	if err == nil {
		return nil
	}
	return kerrors.Forbidden("FORBIDDEN", err.Error()).WithCause(err)
}

// SkipOperations returns a Skip function that skips middleware for exact Kratos operations.
// Generated Kratos operations are usually full method names such as /pkg.Service/Method.
func SkipOperations(ops ...string) func(context.Context, any) bool {
	set := make(map[string]struct{}, len(ops))
	for _, op := range ops {
		op = strings.TrimSpace(op)
		if op != "" {
			set[op] = struct{}{}
		}
	}
	return func(ctx context.Context, _ any) bool {
		_, ok := set[operation(ctx)]
		return ok
	}
}

// SkipOperationPrefixes returns a Skip function that skips middleware for operations
// matching any supplied prefix.
func SkipOperationPrefixes(prefixes ...string) func(context.Context, any) bool {
	clean := make([]string, 0, len(prefixes))
	for _, prefix := range prefixes {
		prefix = strings.TrimSpace(prefix)
		if prefix != "" {
			clean = append(clean, prefix)
		}
	}
	return func(ctx context.Context, _ any) bool {
		op := operation(ctx)
		for _, prefix := range clean {
			if strings.HasPrefix(op, prefix) {
				return true
			}
		}
		return false
	}
}

// OrSkip combines multiple Skip functions.
func OrSkip(fns ...func(context.Context, any) bool) func(context.Context, any) bool {
	return func(ctx context.Context, req any) bool {
		for _, fn := range fns {
			if fn != nil && fn(ctx, req) {
				return true
			}
		}
		return false
	}
}
