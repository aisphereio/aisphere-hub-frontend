package middleware

import (
	"context"
	"log/slog"
	"time"

	"github.com/actionlab-ai/aisphere-kit/audit"
	kitlog "github.com/actionlab-ai/aisphere-kit/logx"
	"github.com/actionlab-ai/aisphere-kit/principal"
	"github.com/go-kratos/kratos/v3/middleware"
)

type AuditResolver func(ctx context.Context, req any, reply any, err error) audit.Event

type AuditOptions struct {
	Component    string
	Resolver     AuditResolver
	Async        bool
	AsyncLimit   int
	AsyncTimeout time.Duration
	Logger       *slog.Logger
	Skip         func(ctx context.Context, req any) bool
}

type AuditOption func(*AuditOptions)

func WithAuditComponent(v string) AuditOption { return func(o *AuditOptions) { o.Component = v } }
func WithAuditResolver(fn AuditResolver) AuditOption {
	return func(o *AuditOptions) { o.Resolver = fn }
}
func WithAuditAsync(v bool) AuditOption     { return func(o *AuditOptions) { o.Async = v } }
func WithAuditAsyncLimit(n int) AuditOption { return func(o *AuditOptions) { o.AsyncLimit = n } }
func WithAuditAsyncTimeout(d time.Duration) AuditOption {
	return func(o *AuditOptions) { o.AsyncTimeout = d }
}
func WithAuditLogger(l *slog.Logger) AuditOption { return func(o *AuditOptions) { o.Logger = l } }
func WithAuditSkip(fn func(context.Context, any) bool) AuditOption {
	return func(o *AuditOptions) { o.Skip = fn }
}

func Audit(r audit.Recorder, opts ...AuditOption) middleware.Middleware {
	o := AuditOptions{AsyncLimit: 1024, AsyncTimeout: 5 * time.Second}
	for _, opt := range opts {
		if opt != nil {
			opt(&o)
		}
	}
	var limit chan struct{}
	if o.Async && o.AsyncLimit > 0 {
		limit = make(chan struct{}, o.AsyncLimit)
	}
	return func(next middleware.Handler) middleware.Handler {
		return func(ctx context.Context, req any) (any, error) {
			if o.Skip != nil && o.Skip(ctx, req) {
				return next(ctx, req)
			}
			logger := o.Logger
			if logger == nil {
				logger = kitlog.FromContext(ctx)
			}
			started := time.Now()
			reply, err := next(ctx, req)
			base := audit.Event{
				Component:  o.Component,
				Operation:  operation(ctx),
				Action:     operation(ctx),
				Resource:   operation(ctx),
				RequestID:  requestID(ctx),
				Method:     "",
				URI:        operation(ctx),
				StatusCode: statusCode(err),
				StartedAt:  started,
				FinishedAt: time.Now(),
			}
			if p, ok := principal.FromContext(ctx); ok {
				base.Actor = p
				base.OrgID = p.OrgID
				base.ProjectID = p.ProjectID
			}
			if o.Resolver != nil {
				base = audit.Merge(base, o.Resolver(ctx, req, reply, err))
			}
			ev := audit.Normalize(ctx, base, err)
			logger.Debug("audit middleware event prepared", "operation", ev.Operation, "action", ev.Action, "resource", ev.Resource, "status", ev.StatusCode)
			if o.Async {
				go audit.RecordAsync(ctx, r, ev, limit, o.AsyncTimeout)
			} else if recErr := audit.Record(ctx, r, ev); recErr != nil {
				logger.Warn("audit middleware record failed", "error", recErr, "operation", ev.Operation)
			}
			return reply, err
		}
	}
}
