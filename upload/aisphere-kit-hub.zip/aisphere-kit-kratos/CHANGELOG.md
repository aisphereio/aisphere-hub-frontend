# Changelog

## v0.2.0

- Add Kratos v3 adapter module separated from core `aisphere-kit`.
- Add authn/authz/audit/metrics/request-id middleware.
- Add HTTP/gRPC server helpers.
- Add `/livez` and `/readyz` handlers.
- Add `starter.MustServe` for Kratos services.
- Keep tracing out of this adapter by default because Kratos v3 tracing package
  path is still moving. Users can add Kratos-native tracing through extra
  middleware once a specific Kratos version is pinned.
