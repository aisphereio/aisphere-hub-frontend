# aisphere-kit-kratos

Kratos adapter for `github.com/actionlab-ai/aisphere-kit`.

This module does **not** initialize MySQL, Redis, MinIO, or Casdoor directly. The
core kit does that. This adapter only connects the core runtime to Kratos:

- authn middleware
- authz middleware with resolver
- audit middleware
- metrics middleware
- request id middleware
- HTTP/gRPC server helpers
- `/livez` and `/readyz` HTTP handlers
- `starter.MustServe` for Kratos services

## Why separate from aisphere-kit?

`aisphere-kit` is framework-neutral and should be usable by CLIs, workers,
migration jobs, and tests. `aisphere-kit-kratos` imports Kratos and should only be
used by Kratos services such as Hub, Runtime, Sandbox, or ModelGateway.

## Install

```bash
go get github.com/actionlab-ai/aisphere-kit@v0.7.0
go get github.com/actionlab-ai/aisphere-kit-kratos@v0.2.0
```

For local development:

```bash
go mod edit -replace github.com/actionlab-ai/aisphere-kit=../aisphere-kit
go mod edit -replace github.com/actionlab-ai/aisphere-kit-kratos=../aisphere-kit-kratos
```

## Hub main.go

```go
package main

import (
    "context"

    "github.com/actionlab-ai/aisphere-hub/internal/app"
    kratosstarter "github.com/actionlab-ai/aisphere-kit-kratos/starter"
)

func main() {
    kratosstarter.MustServe(context.Background(), kratosstarter.ServeOptions{
        ConfigPaths: []string{"configs/config.yaml"},
        NewApp:      app.NewApp,
    })
}
```

## App factory signature

```go
func NewApp(ctx context.Context, cfg *config.Config, rt *starter.Runtime) (*kratos.App, func(), error)
```

Inside the business service you still use the core runtime:

```go
rt.DB
rt.Redis
rt.S3
rt.Authn
rt.Authz
rt.Audit
rt.Permission
```

## Authz middleware

Authz needs a resource/action resolver. For many business APIs it is better to
perform fine-grained authz in the usecase, because only the business layer knows
the real resource id. Middleware authz is optional and useful for coarse-grained
routes.

