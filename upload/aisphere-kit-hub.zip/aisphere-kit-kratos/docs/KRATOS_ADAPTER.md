# Kratos Adapter Design

`aisphere-kit-kratos` is intentionally thin.

## It owns

- converting `authn.Authenticator` into Kratos middleware
- converting `authz.Authorizer` into Kratos middleware
- converting `audit.Recorder` into Kratos middleware
- request metrics middleware
- request id middleware
- HTTP/gRPC server helpers
- `/livez` and `/readyz` handlers
- service bootstrapping through `starter.Serve`

## It does not own

- MySQL initialization
- Redis initialization
- MinIO initialization
- Casdoor SDK initialization
- Casbin policy management
- business resource lifecycle
- business API registration

Those remain in `aisphere-kit` core or the business component.

## Authz guidance

Fine-grained authorization should usually be performed in the business usecase:

```go
err := authz.Require(ctx, rt.Authz, resource.AIHubSkill(skillID).String(), action.SkillUpdate)
```

Middleware authorization is optional and only suitable when the resource/action can be resolved from the request without extra database lookup.

## Tracing guidance

This adapter does not add a custom tracing implementation. Kratos has its own tracing middleware ecosystem, and the exact v3 tracing package path is still moving. Add Kratos-native tracing through `WithChainExtra(...)` after pinning the Kratos version in the service.
