# Verify

```bash
go mod tidy
go test ./...
go build ./...
```

When developing with unpublished local kit modules:

```bash
go mod edit -replace github.com/actionlab-ai/aisphere-kit=../aisphere-kit
go mod tidy
go test ./...
```
