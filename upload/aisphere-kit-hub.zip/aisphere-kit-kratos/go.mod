module github.com/actionlab-ai/aisphere-kit-kratos

go 1.25

// Direct dependency versions are intentionally resolved by `go mod tidy`.
// Kratos v3 is currently distributed as a pseudo-version, so this module avoids
// pinning a hand-written pseudo-version in the template source.
